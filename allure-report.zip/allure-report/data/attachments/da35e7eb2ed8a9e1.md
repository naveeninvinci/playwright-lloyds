# Test info

- Name: Chosen either a single or multiple products >> JS Checkout: iFrame randomly selectedCard
- Location: /Users/naveeninvincible/Documents/Playwright Lloyds/tests/checkoutFlow.spec.js:45:9

# Error details

```
Error: locator.waitFor: Test ended.
Call log:
  - waiting for locator('[data-ui-id="message-success"]') to be visible

    at handleOrderResult (/Users/naveeninvincible/Documents/Playwright Lloyds/utils/checkoutHelpers.js:145:18)
    at /Users/naveeninvincible/Documents/Playwright Lloyds/tests/checkoutFlow.spec.js:65:19
```

# Test source

```ts
   45 |   await page.fill('input[name="street[0]"]', data.street1);
   46 |   await page.fill('input[name="street[1]"]', data.street2);
   47 |   await page.selectOption('select[name="country_id"]', data.country);
   48 |   await page.fill('input[name="city"]', data.city);
   49 |   await page.fill('input[name="postcode"]', data.postcode);
   50 |   await page.fill('input[name="telephone"]', data.telephone);
   51 |
   52 |   // Choose a shipping method randomly
   53 |   const shippingOptions = ['ko_unique_4', 'ko_unique_5'];
   54 |   const chosenOption = shippingOptions[Math.floor(Math.random() * shippingOptions.length)];
   55 |   const shippingMethod = page.locator(`input[type="radio"][name="${chosenOption}"]`);
   56 |
   57 |   await expect(shippingMethod).toBeVisible({ timeout: 10000 });
   58 |   await shippingMethod.check();
   59 |
   60 |   console.log(`📦 Selected shipping method: ${chosenOption}`);
   61 |
   62 |
   63 |   let expectedPrice = null;
   64 |
   65 |   // If ko_unique_5 is selected, store its price
   66 |   if (chosenOption === 'ko_unique_5') {
   67 |     const priceElement = page
   68 |       .locator('input[name="ko_unique_5"]')
   69 |       .locator('xpath=ancestor::tr//td[contains(@class, "col-price")]//span[@class="price"]')
   70 |       .first();
   71 |   
   72 |     await expect(priceElement).toBeVisible({ timeout: 5000 });
   73 |   
   74 |     const priceText = await priceElement.textContent();
   75 |     expectedPrice = priceText?.trim();
   76 |   
   77 |     console.log('💰 Extracted shipping price:', expectedPrice);
   78 |   }
   79 |
   80 |   await page.locator('button[data-role="opc-continue"]').click();
   81 |
   82 |   return { chosenOption, expectedPrice };
   83 |
   84 | }
   85 |
   86 | async function selectLloydsCardnetPaymentJs(page) {
   87 |   const label = page.locator('label[for="lcnetpaymentjs"]');
   88 |   await expect(label).toBeVisible({ timeout: 5000 });
   89 |   await label.click();
   90 | }
   91 |
   92 | async function selectLloydsCardnetConnect(page) {
   93 |   const label = page.locator('label[for="lcnetredirect"]');
   94 |   await expect(label).toBeVisible({ timeout: 5000 });
   95 |   await label.click();
   96 | }
   97 |
   98 | async function fillPaymentDetails(page, card) {
   99 |   await expect(page.frameLocator('#first-data-payment-field-name').locator('input#name')).toBeVisible({ timeout: 10000 });
  100 |   await page.frameLocator('#first-data-payment-field-name').locator('input#name').fill(card.name);
  101 |   await page.frameLocator('#first-data-payment-field-card').locator('input#card').fill(card.number);
  102 |   await page.frameLocator('#first-data-payment-field-exp').locator('input#exp').fill(card.exp);
  103 |   await page.frameLocator('#first-data-payment-field-cvv').locator('input').fill(card.cvv);
  104 |   await page.frameLocator('#first-data-payment-field-cvv').locator('input').press('Tab');
  105 | }
  106 |
  107 | /**
  108 |  * Fills redirect payment details and handles 3DS choice
  109 |  * @param {import('@playwright/test').Page} page 
  110 |  * @param {Object} card 
  111 |  * @param {'yes' | 'no'} [choice='yes'] - Which 3DS button to click
  112 |  */
  113 |
  114 | async function fillRedirectPaymentDetails(page, card, choice = 'yes') {
  115 |   const expMonth = card.exp.slice(0, 2);
  116 |   const expYear = '20' + card.exp.slice(2);
  117 |
  118 |   await expect(page.locator('#select2-brandTypeSelect-container')).toBeVisible({ timeout: 20000 });
  119 |   await page.locator('#select2-brandTypeSelect-container').click();
  120 |   await expect(page.locator('.select2-results__option', { hasText: 'VISA' })).toBeVisible();
  121 |   await page.locator('.select2-results__option', { hasText: 'VISA' }).click();
  122 |
  123 |   await page.locator('#cardNumber').fill(card.number);
  124 |   await page.locator('#expiryMonth').selectOption(expMonth);
  125 |   await page.locator('#expiryYear').selectOption(expYear);
  126 |   await page.locator('#cardCode_masked').type(card.cvv);
  127 |   await page.click('#nextBtn');
  128 |   console.log('Submitted card details');
  129 |
  130 |   // 🔐 Handle 3DS authentication
  131 |   await handle3DSChallenge(page, choice);
  132 | }
  133 |
  134 | export async function handleOrderResult(page, flowType, shouldExpectFailure = false) {
  135 |   const successMsg = page.locator('[data-ui-id="message-success"]');
  136 |   // Select only the first error message to avoid strict mode violation
  137 |   const errorMsg = page.locator('[data-ui-id="checkout-cart-validationmessages-message-error"]').first();
  138 |
  139 |   try {
  140 |     const race = shouldExpectFailure
  141 |     ? Promise.race([
  142 |         successMsg.waitFor({ timeout: 25000 }),
  143 |         errorMsg.waitFor({ timeout: 25000 }),
  144 |       ])
> 145 |     : successMsg.waitFor({ timeout: 25000 });
      |                  ^ Error: locator.waitFor: Test ended.
  146 |
  147 |   await race;
  148 |
  149 |   if (await successMsg.isVisible()) {
  150 |     console.log('✅ Success message appeared');
  151 |     if (flowType === 'iframe') {
  152 |       await verifyIframeSuccessMessage(page);
  153 |     } else if (flowType === 'redirect') {
  154 |       await verifyRedirectSuccessMessage(page);
  155 |     } else {
  156 |       throw new Error(`Unknown flow type: ${flowType}`);
  157 |     }
  158 |   } else if (shouldExpectFailure && await errorMsg.isVisible()) {
  159 |     console.log('❌ Error message appeared');
  160 |     await verifyPaymentFailureMessage(page, flowType);
  161 |   } else {
  162 |     throw new Error('⚠️ Expected success message, but none appeared.');
  163 |   } 
  164 |   } catch (error) {
  165 |     console.error('❗️Neither success nor error message appeared within timeout. Taking screenshot...');
  166 |     try {
  167 |       await page.screenshot({ path: `screenshots/missing-message-${Date.now()}.png`, fullPage: true });
  168 |     } catch (screenshotError) {
  169 |       console.warn('⚠️ Could not take screenshot — page may already be closed.');
  170 |     }
  171 |     throw error;
  172 |   }
  173 | }
  174 |
  175 | async function fillFirstVisible(locator, action, value) {
  176 |   const count = await locator.count();
  177 |   for (let i = 0; i < count; i++) {
  178 |     const el = locator.nth(i);
  179 |     if (await el.isVisible()) {
  180 |       if (action === 'fill') await el.fill(value);
  181 |       if (action === 'select') await el.selectOption(value);
  182 |       return;
  183 |     }
  184 |   }
  185 |   throw new Error(`No visible element found for action: ${action}`);
  186 | }
  187 |
  188 | async function clickFirstVisibleButton(page, selector) {
  189 |   const buttons = page.locator(selector);
  190 |   const count = await buttons.count();
  191 |   for (let i = 0; i < count; i++) {
  192 |     const btn = buttons.nth(i);
  193 |     if (await btn.isVisible()) {
  194 |       await btn.click();
  195 |       return;
  196 |     }
  197 |   }
  198 |   throw new Error(`No visible button found for selector: ${selector}`);
  199 | }
  200 |
  201 | async function fillBillingAddressConditionally(page, billingData) {
  202 |    // Try both possible checkbox IDs
  203 |    const checkboxSelectors = [
  204 |     '#billing-address-same-as-shipping-lcnetredirect',
  205 |     '#billing-address-same-as-shipping-lcnetpaymentjs'
  206 |   ];
  207 |
  208 |   let checkbox;
  209 |   for (const selector of checkboxSelectors) {
  210 |     const candidate = page.locator(selector);
  211 |     try {
  212 |       await expect(candidate).toBeVisible({ timeout: 3000 });
  213 |       checkbox = candidate;
  214 |       break; // Found the first visible one
  215 |     } catch {
  216 |       // Not visible or not found — move on to the next
  217 |     }
  218 |   }
  219 |
  220 |   if (!checkbox) {
  221 |     console.warn('⚠️ Billing address checkbox not found or visible.');
  222 |     return;
  223 |   }
  224 |
  225 |   const shouldUncheck = Math.random() < 0.5;
  226 |   const isChecked = await checkbox.isChecked();
  227 |
  228 |   if (shouldUncheck && isChecked) {
  229 |     await checkbox.uncheck();
  230 |     console.log('🟡 Randomly chose: Use different billing address');
  231 |     // Wait up to 15 seconds for the form to appear in DOM
  232 | await page.waitForSelector('fieldset[data-form="billing-new-address"]', { state: 'attached', timeout: 15000 });
  233 |
  234 |     const formExists = await page.$('fieldset[data-form="billing-new-address"]');
  235 | console.log('Billing form exists in DOM?', !!formExists);
  236 |
  237 |
  238 | const billingFieldset = page.locator('fieldset[data-form="billing-new-address"]');
  239 |
  240 | await fillFirstVisible(billingFieldset.locator('input[name="firstname"]'), 'fill', billingData.firstname);
  241 |     await fillFirstVisible(billingFieldset.locator('input[name="lastname"]'), 'fill',  billingData.lastname);
  242 |     await fillFirstVisible(billingFieldset.locator('input[name="company"]'), 'fill',  billingData.company);
  243 |     await fillFirstVisible(billingFieldset.locator('input[name="street[0]"]'), 'fill',  billingData.street1);
  244 |     await fillFirstVisible(billingFieldset.locator('input[name="street[1]"]'), 'fill',  billingData.street2);
  245 |     await fillFirstVisible(billingFieldset.locator('select[name="country_id"]'),'select',  billingData.country);
```